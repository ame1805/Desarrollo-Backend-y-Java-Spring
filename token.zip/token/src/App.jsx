import React, { useState, useEffect } from "react";

import "./App.css";

function App() {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [protectedData, setProtectedData] = useState(null);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:3001/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: user, password }),
      });

      const data = await res.json();

      console.log("Tokens recibidos:", data);

      if (res.ok) {
        localStorage.setItem("accessToken", data.accessToken);
        localStorage.setItem("refreshToken", data.refreshToken);
        alert("Inicio de sesión exitoso");
      } else {
        alert(data.message || "Error en inicio de sesión");
      }
    } catch (error) {
      console.error("Error al conectar con el backend:", error);
      alert("Error de conexión");
    }
  };

  async function refreshAccessToken() {
    const refreshToken = localStorage.getItem("refreshToken");
    if (!refreshToken) return null;

    try {
      const res = await fetch("http://localhost:3001/api/token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: refreshToken }),
      });
      const data = await res.json();

      if (res.ok) {
        localStorage.setItem("accessToken", data.accessToken);
        return data.accessToken;
      } else {
        // Refresh token inválido o expirado, pedir login otra vez
        alert("Tu sesión expiró, por favor inicia sesión nuevamente.");
        return null;
      }
    } catch (error) {
      console.error("Error al renovar token:", error);
      return null;
    }
  }

  useEffect(() => {
    const interval = setInterval(() => {
      refreshAccessToken();
    }, 4 * 60 * 1000); // cada 4 minutos

    return () => clearInterval(interval); // limpiar al desmontar
  }, []);

useEffect(() => {
  const fetchProtected = async () => {
    let token = localStorage.getItem("accessToken");
    if (!token) {
      console.log("No hay token, no se hace la petición protegida.");
      return;
    }

    let res = await fetch("http://localhost:3001/api/protegido", {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (res.status === 401 || res.status === 403) {
      token = await refreshAccessToken();
      if (token) {
        res = await fetch("http://localhost:3001/api/protegido", {
          headers: { Authorization: `Bearer ${token}` },
        });
      } else {
        return;
      }
    }

    if (res.ok) {
      const data = await res.json();
      setProtectedData(data);
    } else {
      setProtectedData(null);
    }
  };

  fetchProtected();
}, []);

  const handleLogout = () => {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    setProtectedData(null);
    alert("Sesión cerrada.");
  };
  return (
    <div className="login-container">
      {!protectedData ? (
        <form className="login-form" onSubmit={handleLogin}>
          <h2>Iniciar Sesión</h2>
          <input
            type="text"
            placeholder="Usuario"
            value={user}
            onChange={(e) => setUser(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit">Ingresar</button>
        </form>
      ) : (
        <div>
          <h3>Datos protegidos:</h3>
          <pre>{JSON.stringify(protectedData, null, 2)}</pre>
          <button onClick={handleLogout}>Cerrar sesión</button>
        </div>
      )}
    </div>
  );
}

export default App;
